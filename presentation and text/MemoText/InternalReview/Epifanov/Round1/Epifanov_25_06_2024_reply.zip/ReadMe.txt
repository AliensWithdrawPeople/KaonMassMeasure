Reviewed version: Memo_Ks_Mass_ver5.5.pdf (dated April 8th 2024)
Review received: 25 Jun 2024
Reply submitted: 26 Jun 2024
Updated version: Memo_Ks_Mass_ver6.pdf (dated Jun 26th 2024)